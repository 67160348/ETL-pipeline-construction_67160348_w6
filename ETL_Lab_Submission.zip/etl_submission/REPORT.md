# ETL Lab Report

**Student ID:** ETL_Student_001  
**Name:** ETL Pipeline Implementation  
**Date:** 2026-08-11

---

## 1. Data Quality Problems Found

โครงการนี้พบปัญหาคุณภาพข้อมูลดังนี้:

### ลูกค้า (Customers)
- ✓ **ข้อมูลลูกค้าซ้ำกัน**: customer_id `C001` ปรากฏ 2 ครั้ง
- ✓ **ค่า province สกปรก**: ค่าจังหวัดไม่สม่ำเสมอ
  - ตัวอักษรพิมพ์ใหญ่-เล็ก: `Bangkok`, `bkk`, `กรุงเทพฯ`
  - สะกดต่างกัน: `chanthaburi`, `chantaburi`, `จันทบุรี`
  - ช่องว่าง: `chon buri` vs `chonburi`
- ✓ **ข้อมูลขาดหายไป**: customer_id `C012`, `C015` ไม่มี province

### สินค้า (Products)
- ✓ **JSON ซ้อน**: `category.name` และ `pricing.price` เป็นข้อมูลซ้อนกัน
- ✓ **ประเภทข้อมูลผิด**: `pricing.price` เป็น string ไม่ใช่ numeric
- ✓ **ข้อมูลขาดหายไป**: product_id `P004` ไม่มี category (NULL)

### คำสั่งซื้อ (Orders)
- ✓ **รูปแบบวันที่ผสม**: วันที่ในรูปแบบต่างกัน
  - ISO format: `2024-01-15`
  - US format: `01/20/2024`
  - EU format: `15-01-2024`
  - Text format: `25 Jan 2024`, `15-Feb-2024`
- ✓ **ค่า quantity ผิด**: 
  - order_id `O006` มี qty = -1 (ค่าลบ)
- ✓ **ค่า unit_price ผิด**: 
  - order_id `O003` มี unit_price = -100 (ค่าลบ)
  - order_id `O005` มี unit_price = 0 (ศูนย์)
- ✓ **ค่า discount_pct ผิด**: 
  - order_id `O004` มี discount_pct = 150% (เกิน 100%)
  - order_id `O007` มี discount_pct = -5% (ค่าลบ)
- ✓ **Status inconsistent**: ตัวอักษรพิมพ์ใหญ่-เล็ก: `PAID`, `paid`, `Paid`, `Completed`, `completed`
- ✓ **ข้อมูล order ซ้ำ**: order_id `O001` ปรากฏ 2 ครั้ง
- ✓ **ลูกค้าไม่มีอยู่**: order_id `O020` มี customer_id `C999` ที่ไม่มีในตาราง customers
- ✓ **สินค้าไม่มีอยู่**: order_id `O015` มี product_id `P999` ที่ไม่มีในตาราง products

---

## 2. Cleaning / Transformation Rules

กฎการทำความสะอาดและการแปลงข้อมูลที่นำไปใช้:

### Customers Transformation
1. **ลบข้อมูลลูกค้าซ้ำ**: เก็บเฉพาะเรกคอร์ดแรก (keep first)
2. **ทำให้ province เป็นมาตรฐาน**: ใช้ PROVINCE_MAP เพื่อแม็พค่าทั้งหมด
   - `bangkok`, `bkk`, `กรุงเทพฯ` → `Bangkok`
   - `chonburi`, `chon buri`, `ชลบุรี` → `Chonburi`
   - `rayong`, `ระยอง` → `Rayong`
   - `chanthaburi`, `chantaburi`, `จันทบุรี` → `Chanthaburi`
3. **จัดการข้อมูลขาดหายไป**: 
   - province ขาดหายไป → `Unknown`
   - email ขาดหายไป → `''` (empty string)

### Products Transformation
1. **แบนฟลาย JSON ที่ซ้อนกัน**: ใช้ `pd.json_normalize()`
   - `category.name` → `category`
   - `pricing.price` → `price`
2. **แปลง price เป็น numeric**: `pd.to_numeric()` with errors='coerce'
3. **จัดการ category ขาดหายไป**: category NULL → `Unknown`
4. **เปลี่ยนชื่อ column**: 
   - `name` → `product_name`

### Orders Transformation
1. **ลบข้อมูล order ซ้ำ**: เก็บเฉพาะเรกคอร์ดแรก
2. **แปลงรูปแบบวันที่ผสม**: ทำให้เป็น datetime format เดียว
   - ลองรูปแบบต่างๆ: ISO, US, EU, Text formats
3. **ทำให้ status เป็นมาตรฐาน**: แปลงเป็น lowercase
4. **ปฏิเสธเรกคอร์ดที่ไม่ถูกต้อง**:
   - qty ≤ 0 ✗
   - unit_price ≤ 0 ✗
   - discount_pct < 0 หรือ > 100 ✗
   - order_date ไม่ถูกต้อง ✗
   - status ≠ 'paid' หรือ 'completed' ✗

### Merge & Calculation
1. **เก็บเฉพาะ paid/completed orders**
2. **Join**: orders + customers + products
3. **ปฏิเสธเรกคอร์ด**:
   - customer ไม่มีในตาราง customers ✗
   - product ไม่มีในตาราง products ✗
4. **คำนวณยอดเงิน**:
   ```
   gross_amount = qty × unit_price
   discount_amount = gross_amount × discount_pct ÷ 100
   sales_amount = gross_amount - discount_amount
   ```

---

## 3. Rejected Records

### สรุป
- **จำนวนเรกคอร์ดที่ถูก reject**: 5 records
- **สาเหตุหลัก**: 
  - unit_price ≤ 0: 2 records
  - discount_pct ไม่ถูกต้อง: 2 records
  - qty ≤ 0: 1 record

### รายละเอียด
| Order ID | Reject Reason | Qty | Unit Price | Discount % |
|----------|---------------|-----|------------|-----------|
| O003 | unit_price ≤ 0 | 3 | -100.00 | 5% |
| O004 | discount_pct > 100 | 1 | 800.00 | 150% |
| O005 | unit_price ≤ 0 | 2 | 0.00 | 10% |
| O006 | qty ≤ 0 | -1 | 550.00 | 15% |
| O007 | discount_pct < 0 | 2 | 450.00 | -5% |

---

## 4. ETL Validation

### ผลลัพธ์ Pipeline

```json
{
  "source_valid_rows": 13,
  "warehouse_rows": 13,
  "duplicate_order_ids": 0,
  "warehouse_total_sales": 14540.00,
  "source_total_sales": 14540.00,
  "status": "PASS"
}
```

### การตรวจสอบรายละเอียด
- **Valid Transformed Rows**: 13 records
  - Original orders: 21 records
  - Rejected: 5 records
  - Duplicate handled: 1 record
  - Unknown customer/product: 1 record
  - **Total Valid**: 13 records ✓

- **Warehouse Rows**: 13 records ✓

- **Duplicate order_id**: 0 duplicates ✓

- **Source Total Sales**: THB 14,540.00

- **Warehouse Total Sales**: THB 14,540.00 ✓

- **Validation Status**: **PASS** ✅
  - Row counts match
  - No duplicate order IDs
  - Sales totals reconciled perfectly

---

## 5. Idempotency Test

### วัตถุประสงค์
ตรวจสอบว่ากระบวนการ ETL สามารถรันหลายครั้งได้โดยไม่เกิดข้อมูลซ้ำในตาราง fact_sales

### ขั้นตอน
1. **Run ครั้งที่ 1**: 
   - database size: 28 KB
   - fact_sales rows: 13

2. **Run ครั้งที่ 2** (rerun the pipeline):
   - database size: 28 KB (ไม่เปลี่ยนแปลง)
   - fact_sales rows: 13 (ไม่เพิ่มขึ้น)

### ผลการทดสอบ
- **Status**: ✅ **PASS - Idempotent**
- **เหตุผล**: 
  - ใช้ `INSERT OR IGNORE` ในการโหลด fact_sales
  - order_id มี UNIQUE constraint
  - ปรากฏว่าข้อมูลซ้ำถูกปฏิเสธโดยอัตโนมัติ
  - Database size คงที่ที่ 28 KB หลังจากรัน 2 ครั้ง
  - Row count ใน fact_sales ยังคงเป็น 13 rows เท่าเดิม
  - ไม่มี duplicate order_id ในทั้งสองคร้ัง

### ผลลัพธ์ย้อนกลับ
```
Before 2nd run: 28K
After 2nd run:  28K
Fact_sales rows: 13 (unchanged)
Duplicate check: 0 duplicates
```

---

## สรุป (Summary)

Pipeline ETL ดำเนินการสำเร็จด้วยการทำความสะอาดข้อมูลอย่างครบถ้วน:
- ✅ Extract: อ่านข้อมูลจาก 4 sources ที่แตกต่างกัน
- ✅ Transform: ทำความสะอาด 5 รายการ reject จาก 21 orders
- ✅ Load: โหลดเข้า SQLite warehouse ด้วย UNIQUE constraints
- ✅ Validate: ทั้ง row counts และ sales totals ตรงกัน 100%
- ✅ Idempotency: สามารถรัน 2 ครั้งโดยไม่เกิดข้อมูลซ้ำ

**Final Status**: 🎉 **PASS**
