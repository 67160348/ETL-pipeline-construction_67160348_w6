import pandas as pd
import numpy as np
from datetime import datetime
from .config import PROVINCE_MAP

def transform_data(raw):
    """
    Comprehensive data cleaning and transformation
    Returns: clean_customers, clean_products, sales, rejects
    """
    
    # ===== CUSTOMERS TRANSFORMATION =====
    customers = raw["customers"].copy()
    
    # Remove duplicate customer_id (keep first occurrence)
    customers = customers.drop_duplicates(subset=['customer_id'], keep='first')
    
    # Standardize province using PROVINCE_MAP
    def standardize_province(prov):
        if pd.isna(prov):
            return np.nan
        prov_str = str(prov).lower().strip()
        return PROVINCE_MAP.get(prov_str, prov)
    
    customers['province'] = customers['province'].apply(standardize_province)
    
    # Handle missing values
    customers['province'] = customers['province'].fillna('Unknown')
    customers['email'] = customers['email'].fillna('')
    
    clean_customers = customers[['customer_id', 'name', 'email', 'province']].copy()
    
    
    # ===== PRODUCTS TRANSFORMATION =====
    products = raw["products"].copy()
    
    # Rename fields
    products = products.rename(columns={
        'name': 'product_name',
        'category.name': 'category_clean',
        'pricing.price': 'price'
    })
    
    # Convert price to numeric
    products['price'] = pd.to_numeric(products['price'], errors='coerce')
    
    # Fill missing category with "Unknown"
    products['category_clean'] = products['category_clean'].fillna('Unknown')
    
    # Select only the columns we need
    clean_products = products[['product_id', 'product_name', 'category_clean', 'price']].copy()
    
    # Rename the cleaned category column back
    clean_products = clean_products.rename(columns={'category_clean': 'category'})
    
    
    # ===== ORDERS TRANSFORMATION & VALIDATION =====
    orders = raw["orders"].copy()
    rejects = []
    
    # Remove duplicate order_id (keep first occurrence)
    orders = orders.drop_duplicates(subset=['order_id'], keep='first')
    
    # Parse mixed date formats
    def parse_mixed_dates(date_str):
        if pd.isna(date_str):
            return None
        
        date_str = str(date_str).strip()
        
        # Try different date formats
        formats = [
            '%Y-%m-%d',      # 2024-01-15
            '%m/%d/%Y',      # 01/20/2024
            '%d-%m-%Y',      # 15-01-2024
            '%Y/%m/%d',      # 2024/01/25
            '%d %b %Y',      # 25 Jan 2024
            '%d-%b-%Y',      # 15-Feb-2024
            '%d %B %Y',      # 20 February 2024
        ]
        
        for fmt in formats:
            try:
                return pd.to_datetime(date_str, format=fmt)
            except:
                continue
        
        # If no format matches, return NaT
        return pd.NaT
    
    orders['order_date'] = orders['order_date'].apply(parse_mixed_dates)
    
    # Normalize status to lowercase
    orders['status'] = orders['status'].str.lower()
    
    # Validate and reject records
    valid_rows = []
    
    for idx, row in orders.iterrows():
        reject_reason = None
        
        # Check qty <= 0
        if pd.isna(row['qty']) or row['qty'] <= 0:
            reject_reason = "qty <= 0"
        
        # Check unit_price <= 0
        elif pd.isna(row['unit_price']) or row['unit_price'] <= 0:
            reject_reason = "unit_price <= 0"
        
        # Check discount_pct < 0 or > 100
        elif pd.isna(row['discount_pct']) or row['discount_pct'] < 0 or row['discount_pct'] > 100:
            reject_reason = "discount_pct invalid"
        
        # Check valid order_date
        elif pd.isna(row['order_date']):
            reject_reason = "invalid order_date"
        
        # Check status is paid or completed
        elif row['status'] not in ['paid', 'completed']:
            reject_reason = "status not paid/completed"
        
        if reject_reason:
            row_dict = row.to_dict()
            row_dict['reject_reason'] = reject_reason
            rejects.append(row_dict)
        else:
            valid_rows.append(row)
    
    if valid_rows:
        orders = pd.DataFrame(valid_rows)
    else:
        orders = pd.DataFrame()
    
    rejects_df = pd.DataFrame(rejects)
    
    
    # ===== MERGE DATA =====
    if len(orders) > 0:
        # Merge orders with customers
        sales = orders.merge(
            clean_customers,
            on='customer_id',
            how='left'
        )
        
        # Merge with products
        sales = sales.merge(
            clean_products,
            on='product_id',
            how='left'
        )
        
        # Reject rows with unknown customer or product
        before_merge = len(sales)
        sales = sales[
            (sales['customer_id'].isin(clean_customers['customer_id'])) &
            (sales['product_id'].isin(clean_products['product_id']))
        ]
        after_merge = len(sales)
        
        # Record rejects from merge
        if before_merge > after_merge:
            lost_rows = before_merge - after_merge
        
        # ===== CALCULATE AMOUNTS =====
        sales['gross_amount'] = sales['qty'] * sales['unit_price']
        sales['discount_amount'] = sales['gross_amount'] * sales['discount_pct'] / 100
        sales['sales_amount'] = sales['gross_amount'] - sales['discount_amount']
        
        # Select final columns
        sales = sales[[
            'order_id',
            'customer_id',
            'product_id',
            'order_date',
            'qty',
            'unit_price',
            'discount_pct',
            'sales_amount'
        ]].copy()
    else:
        sales = pd.DataFrame()
    
    return clean_customers, clean_products, sales, rejects_df
