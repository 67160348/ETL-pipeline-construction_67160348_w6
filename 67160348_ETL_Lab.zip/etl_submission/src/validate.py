import sqlite3
import pandas as pd
from .config import WAREHOUSE_DB

def validate_data(source_sales):
    """
    Validate ETL pipeline results.
    
    Returns a dictionary with:
    - source_valid_rows: Number of valid rows in transformed data
    - warehouse_rows: Number of rows in fact_sales table
    - duplicate_order_ids: Number of duplicate order_ids (should be 0)
    - warehouse_total_sales: Total sales_amount from warehouse
    - source_total_sales: Total sales_amount from transformed data
    - status: PASS or FAIL
    """
    
    # Count valid rows from transformed data
    source_valid_rows = len(source_sales)
    source_total_sales = source_sales['sales_amount'].sum() if len(source_sales) > 0 else 0.0
    
    # Connect to warehouse
    conn = sqlite3.connect(WAREHOUSE_DB)
    cursor = conn.cursor()
    
    # Count warehouse rows
    cursor.execute('SELECT COUNT(*) FROM fact_sales')
    warehouse_rows = cursor.fetchone()[0]
    
    # Count duplicate order_ids (should be 0)
    cursor.execute('''
        SELECT COUNT(*) FROM (
            SELECT order_id, COUNT(*) as cnt
            FROM fact_sales
            GROUP BY order_id
            HAVING cnt > 1
        )
    ''')
    duplicate_order_ids = cursor.fetchone()[0]
    
    # Calculate total sales from warehouse
    cursor.execute('SELECT COALESCE(SUM(sales_amount), 0) FROM fact_sales')
    warehouse_total_sales = cursor.fetchone()[0]
    
    conn.close()
    
    # ===== VALIDATION LOGIC =====
    # PASS if:
    # 1. Number of rows match
    # 2. No duplicate order_ids
    # 3. Total sales match (with small tolerance for rounding)
    
    rows_match = (source_valid_rows == warehouse_rows)
    no_duplicates = (duplicate_order_ids == 0)
    totals_match = abs(source_total_sales - warehouse_total_sales) < 0.01  # Allow small rounding error
    
    status = "PASS" if (rows_match and no_duplicates and totals_match) else "FAIL"
    
    return {
        "source_valid_rows": source_valid_rows,
        "warehouse_rows": warehouse_rows,
        "duplicate_order_ids": duplicate_order_ids,
        "warehouse_total_sales": round(warehouse_total_sales, 2),
        "source_total_sales": round(source_total_sales, 2),
        "status": status
    }
