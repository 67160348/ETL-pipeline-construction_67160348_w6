import json
import logging
from .config import LOG_DIR, OUTPUT_DIR
from .extract import extract_data
from .transform import transform_data
from .load import load_data
from .validate import validate_data

def main():
    LOG_DIR.mkdir(exist_ok=True)
    OUTPUT_DIR.mkdir(exist_ok=True)

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(message)s",
        handlers=[
            logging.FileHandler(LOG_DIR / "etl.log", encoding="utf-8"),
            logging.StreamHandler()
        ]
    )

    logging.info("ETL started")

    raw = extract_data()
    logging.info(f"Extracted: {len(raw['customers'])} customers, {len(raw['orders'])} orders, {len(raw['products'])} products, {len(raw['stores'])} stores")
    
    customers, products, sales, rejects = transform_data(raw)
    logging.info(f"Transformed: {len(customers)} customers, {len(products)} products, {len(sales)} sales, {len(rejects)} rejects")

    rejects.to_csv(OUTPUT_DIR / "rejects.csv", index=False)
    logging.info(f"Rejects saved to {OUTPUT_DIR / 'rejects.csv'}")

    load_data(customers, products, sales)
    logging.info("Data loaded to warehouse")

    result = validate_data(sales)
    (OUTPUT_DIR / "validation.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2),
        encoding="utf-8"
    )
    logging.info(f"Validation result: {result['status']}")

    logging.info("ETL completed")
    print(json.dumps(result, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
