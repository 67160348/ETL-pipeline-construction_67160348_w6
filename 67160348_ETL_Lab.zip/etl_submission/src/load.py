import sqlite3
import pandas as pd
import numpy as np
from .config import WAREHOUSE_DB

def load_data(customers, products, sales):
    """
    Load data into SQLite warehouse with proper constraints.
    
    Tables created:
      - dim_customer (customer_id UNIQUE)
      - dim_product (product_id UNIQUE)
      - fact_sales (order_id UNIQUE, idempotent)
    
    Running twice must NOT duplicate fact_sales.
    """
    
    conn = sqlite3.connect(WAREHOUSE_DB)
    cursor = conn.cursor()
    
    # ===== CREATE dim_customer TABLE =====
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS dim_customer (
            customer_id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            email TEXT,
            province TEXT NOT NULL
        )
    ''')
    
    # ===== CREATE dim_product TABLE =====
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS dim_product (
            product_id TEXT PRIMARY KEY,
            product_name TEXT NOT NULL,
            category TEXT,
            price REAL NOT NULL
        )
    ''')
    
    # ===== CREATE fact_sales TABLE =====
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS fact_sales (
            order_id TEXT PRIMARY KEY,
            customer_id TEXT NOT NULL,
            product_id TEXT NOT NULL,
            order_date DATE NOT NULL,
            qty INTEGER NOT NULL,
            unit_price REAL NOT NULL,
            discount_pct REAL NOT NULL,
            sales_amount REAL NOT NULL,
            FOREIGN KEY (customer_id) REFERENCES dim_customer(customer_id),
            FOREIGN KEY (product_id) REFERENCES dim_product(product_id)
        )
    ''')
    
    conn.commit()
    
    # ===== LOAD CUSTOMERS =====
    # Use INSERT OR REPLACE for idempotency (upsert)
    for idx, row in customers.iterrows():
        cursor.execute('''
            INSERT OR REPLACE INTO dim_customer
            (customer_id, name, email, province)
            VALUES (?, ?, ?, ?)
        ''', (
            str(row['customer_id']),
            str(row['name']),
            str(row['email']) if pd.notna(row['email']) else '',
            str(row['province'])
        ))
    
    conn.commit()
    
    # ===== LOAD PRODUCTS =====
    # Use INSERT OR REPLACE for idempotency (upsert)
    for idx, row in products.iterrows():
        category = row['category']
        if pd.isna(category):
            category = 'Unknown'
        else:
            category = str(category)
        
        price = row['price']
        if pd.isna(price):
            price = 0.0
        else:
            price = float(price)
            
        cursor.execute('''
            INSERT OR REPLACE INTO dim_product
            (product_id, product_name, category, price)
            VALUES (?, ?, ?, ?)
        ''', (
            str(row['product_id']),
            str(row['product_name']),
            category,
            price
        ))
    
    conn.commit()
    
    # ===== LOAD SALES (FACT) =====
    # Use INSERT OR IGNORE for idempotency
    # This ensures order_id uniqueness and prevents duplicates on reruns
    for idx, row in sales.iterrows():
        cursor.execute('''
            INSERT OR IGNORE INTO fact_sales
            (order_id, customer_id, product_id, order_date, qty, unit_price, discount_pct, sales_amount)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            str(row['order_id']),
            str(row['customer_id']),
            str(row['product_id']),
            str(row['order_date']),
            int(row['qty']),
            float(row['unit_price']),
            float(row['discount_pct']),
            float(row['sales_amount'])
        ))
    
    conn.commit()
    conn.close()
