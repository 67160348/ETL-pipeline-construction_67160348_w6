# ETL Lab Report

**Student ID:** 67160348  
**Name:** บุณยนุช มโนมัยสกุล

---

## 1. Data Quality Problems Found

### ปัญหาที่พบ
- ข้อมูลลูกค้าซ้ำกัน (duplicate customer_id)
- รูปแบบจังหวัด (province) ไม่สม่ำเสมอ (Bangkok, bkk, กรุงเทพฯ)
- รูปแบบวันที่ผสม (mixed date formats - 7 แบบ)
- ค่า quantity ลบ (qty ≤ 0)
- ค่า unit_price ลบหรือศูนย์ (price ≤ 0)
- ค่า discount ไม่ถูกต้อง (< 0 หรือ > 100%)
- JSON ซ้อนกัน (nested JSON fields)
- ข้อมูลขาดหายไป (missing values)

---

## 2. Cleaning / Transformation Rules

### การแก้ไข
- **Duplicates**: ลบเรกคอร์ดซ้ำ (keep first)
- **Province**: ใช้ PROVINCE_MAP ทำให้เป็นมาตรฐาน 4 ค่า (Bangkok, Chonburi, Rayong, Chanthaburi)
- **Date**: แปลง 7 รูปแบบแตกต่างให้เป็น datetime เดียว
- **Price/Qty/Discount**: ตรวจสอบค่า ถ้าไม่ถูกต้องให้ reject
- **JSON**: ใช้ pd.json_normalize() ทำให้เป็น flat columns
- **Missing**: แทนด้วย Unknown หรือ empty string
- **Calculation**:
  - gross_amount = qty × unit_price
  - discount_amount = gross_amount × discount_pct ÷ 100
  - sales_amount = gross_amount - discount_amount

---

## 3. Rejected Records

### จำนวน:
**5 records ถูก reject**

### เหตุผลหลัก:
| Order ID | Reason | Details |
|----------|--------|---------|
| O003 | unit_price ≤ 0 | price = -100 |
| O004 | discount > 100% | discount = 150% |
| O005 | unit_price ≤ 0 | price = 0 |
| O006 | qty ≤ 0 | qty = -1 |
| O007 | discount < 0% | discount = -5% |

---

## 4. ETL Validation

- **Valid transformed rows:** 13 rows
- **Warehouse rows:** 13 rows
- **Duplicate order_id:** 0 (ไม่มีซ้ำ)
- **Source total sales:** ฿14,540.00
- **Warehouse total sales:** ฿14,540.00
- **Validation status:** ✅ **PASS**

---

## 5. Idempotency Test

### จำนวน fact_sales หลัง run ครั้งที่ 1:
**13 rows**

### จำนวน fact_sales หลัง run ครั้งที่ 2:
**13 rows** (ไม่เพิ่มขึ้น)

### อธิบายผล:
✅ **PASS** - Pipeline เป็น idempotent (ไม่มีข้อมูลซ้ำเมื่อรันสองครั้ง)

**เหตุผล**: ใช้ `INSERT OR IGNORE` และ UNIQUE constraint บน order_id ทำให้รันครั้งที่ 2 ไม่เพิ่มเรกคอร์ดซ้ำ

---

**สรุป**: Pipeline ทำงานถูกต้อง 100% - ✅ PASS
